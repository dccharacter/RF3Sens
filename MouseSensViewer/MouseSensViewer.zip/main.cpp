#include <QApplication>

#include "dialog.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Dialog dialog;
    dialog.setWindowFlags(Qt::Window);
    dialog.show();
    return app.exec();
}
